Crazyflie Arduino Controller Demo

This is a simple Arduino sketch to demonstrate the capability to use an Arduino
Nano connected to a h(ij)acked PS1 controller and a nRF24L01+PA board to fly a
CrazyFlie 2.0.

From tbitson's original project and code.

Wiring:
See code listing

Photos: see Build Info
